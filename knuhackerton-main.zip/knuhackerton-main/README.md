# BLD-Status of KNU
COVID-19로 변화된 대학 생활을 개선할 수 있는 창의적이고 혁신적인 소프트웨어 개발

## 주제
실시간 위치추적을 통한 캠퍼스 내 건물 상태 확인

## 팀원
이름|학번|E-mail
--|--|--
고동연(팀장) | 2021113766 | quanta4578@gmail.com
김준형 | 2021114930 | junhyung85920@gmail.com
김은혜 | 2021114094 | kittus030709@gmail.com
송재훈 | 2021116588 | ssongdev@gmail.com

## 시연영상 및 서버주소
* [Youtube 주소](https://youtu.be/XlsI570OM6c)
* [서버 주소](https://fresh-server-320303.web.app/)

## 특징

코로나 19에 감염된 우리 학교 학생들의 확진일자나 동선이 불문명하고, 정보 업데이트도 느려서 다른 학생들의 2차 감염 예방에 차질이 생긴다. 
이로 인해 우리 팀은 이러한 문제를 개선하기 위해 GPS기반의 실시간 정보 업데이트를 지도를 통하여 나타내었다. 
건물을 눌렀을 때, 해당 건물의 상태를 색과 정보를 통해 알려지게 하였으며, 신속한 업데이트를 통해 코로나 19 확산을 막는 데 이바지 하는 프로그램을 만들었다.

건물에 마우스 커서를 갖다댔을 때 건물 전체 수용가능 인원수대비 현재인원수가 나오고 앞서 나온 현재인원수와 확진자 방문여부에 따른 위험치를 각각 적색, 주황색, 녹색으로 나타내며
최근 2주내 확진자가 다녀간 사실과 확진자의 이동 동선을 각 건물들마다 제시해준다.

이 기능은 Google map API 와 Firebase를 이용하여 만들었다. Firebase Realtime Database를 이용하니 Firebase가 설치되어 있어야 실행이 된다.
* Google Maps api (https://developers.google.com/maps)
* Google Terms of servie (https://cloud.google.com/maps-platform/terms)
* Firebase (https://firebase.google.com/)

Firebase 설치 방법은 https://firebase.google.com/docs/web/setup 를 참조한다.

각 js와 css의 기능은 다음과 같다.

### areas.js
이 파일에는 건물 번호,이름, 좌표,Polgon(건물마크)에 대한 좌표 정보와 현재 수용 가능 인원에 대한 정보가 담겨있다. 이 파일에는 우리 학교 건물를 지도에 나타내고 레이아웃을 이용하여 마우스 오버와 아웃 이벤트 발생시 건물에 대한 정보가 뜨게 하였으며, 확진자가 다녀간 건물은 infected.js에 저장해 놓은 데이터 들을 토대로 safe와 visited와 exceeded 를 표시했다.

또한 건물의 면적을 계산하여 최대 수용 가능 인원대비 현재 인원 수를 파악하여, 확진자 방문여부와 더불어 건물의 위험도를 파악하는 코드를 작성하였다.마지막으로 areas에 있는 id는 건물 id로써 위치추적에 쓰이기 위해 작성된 데이터이다.

### index.js
현재 인원수 건물의 scale(최대수용인원)과 비교하여 status를 exceeded로 바꾸거나 safe로 유지하고
다른 js 파일에서 변화된 status를 바탕으로 colorChange() 함수를 통해 각 건물의 상태를 반환한다.
웹에 나타나는 전반적인 것들(infoWindow, 건물 구역, 건물 정보, 건물 색, 투명도 등등)
을 설정하고 gps location을 받아온다.

### infected.js
확진자가 방문한 건물 번호를 받아 areas배열에 대응되는 index값을 구하고 
해당 index의 info배열에 상세정보를 입력하고, status변수를 VISTIED로 바꿔준다.

Date객체를 이용해 확진판정받은 날짜로 부터 14일이 지나면 더이상 지도 상에 표시되지 않도록 한다.

### infectedPerson.js
확진 판정 받은 날짜, 소속대학, 방문한 건물, 그 외 정보들을 정리해둔 파일이다.

### location.js
initFirebase가 유저 데이터가 변경됨으로 인해 실시간으로 업데이트 된다.
/usr/ USERID / {placeID : , userID : } 와 같은 형태로 저장이 되는데 userID를 통해 중복되는 숫자가 없도록 하고 userLocationData는 {placeID : ,times : }와 같이 그 장소에 몇명이 있는지 알 수 있도록 했다.

addToFirebase는 데이터를 실시간으로 변경하게 해주고, 유저가 나가면 데이터가 삭제되게 해주는 함수이다.

### style.css

구글 맵 초기 설정 및 건물상태에 따른 infoWindow의 status 항목의 색 변화가 있는 파일이다.
건물상태에 따라서 확진자가 방문한 건물은 위험도를 나타내기 위해 빨간색으로 나타냈으며 safe는 비교적 안전한 곳이라는 것을 나타내기 위해 녹색으로 표새하였고, 확진자는 방문하지 않았지만, 현재 건물 내 인원수가 많아 주의해야 할 곳인 exceeded는 주황색으로 글씨 색상에 변화를 주며 시각적인 효과를 주었다.

