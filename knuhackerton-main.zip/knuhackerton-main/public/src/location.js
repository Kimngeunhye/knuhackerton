var placeData = []

function initFirebase(){
    var ref = firebase.database().ref('usr');
    ref.on('value',function(snapshot){
        snapshot.forEach(function(childSnapshot){
            var childData = childSnapshot.val();
            placeData.push({userID : childData.userID, placeID : childData.placeID});
        })
    });
    
    function removeDuplicates(originalArray, prop) {
        var newArray = [];
        var lookupObject  = {};
   
        for(var i in originalArray) {
           lookupObject[originalArray[i][prop]] = originalArray[i];
        }
   
        for(i in lookupObject) {
            newArray.push(lookupObject[i]);
        }
         return newArray;
    }

   var locationData = removeDuplicates(placeData, "userID");
   var userLocationData = [];
   locationData.map(item => {
       if(userLocationData.find(object => {
           if(object.Name === item.Name && object.placeID === item.placeID) {
               object.times++;
               return true;
           } else {
               return false;
           }
       })){
       } else {
           item.times = 1;
           userLocationData.push(item);
       }
   })
   for(var i = 0; i < userLocationData.length; i++){
       delete userLocationData[i].userID
   }

   for(var l = 0; l < userLocationData.length; l++){
       for(var k = 0; k < areas.length; k++){
           if(userLocationData[l].placeID == areas[k].id){
               areas[k].current = userLocationData[l].times
           }
       }
   }

   userLocationData = [];
}

function addToFirebase(placeID) {
    firebase.database().ref('usr/' + data.userID).set({
        placeID : placeID,
        userID : data.userID
    });

    firebase.database().ref('usr/' + data.userID).onDisconnect().remove();
  }
