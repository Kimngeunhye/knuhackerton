function initMap() {


  // Google Map initial setting
  const map = new google.maps.Map(document.getElementById("map"), {
    zoom: 17,
    center: { lat: 35.88900112853728, lng: 128.61028896909824 },
  });


  // google polygon
  function deleteBLD(){
    for(var i = 0; i < bldList.length; i++){
      bldList[i].setMap(null)
    }
  }


  // status : safe, visited, exceeded
  function colorChange(){
    deleteBLD();

    for(var i = 0; i < areas.length; i++){
      var percent = areas[i].current / areas[i].scale * 100;
      if(percent >= 80 && areas[i].status != "VISITED") {
        areas[i].status = "EXCEEDED";
      }
      else if(percent < 80 && areas[i].status != "VISITED") {
        areas[i].status = "SAFE";
      }         
      switch(areas[i].status){
          case "VISITED":
            setArea(areas[i].current, areas[i].num, areas[i].name, areas[i].status, areas[i].info, areas[i].marker, areas[i].path, '#FB0D0D', '#F79696', "#CB0000");
            break;
          
          case "EXCEEDED":
            setArea(areas[i].current, areas[i].num, areas[i].name, areas[i].status, areas[i].info, areas[i].marker, areas[i].path, '#F58821', '#FAD7BD', '#FF6C00');
            break;
        
          case "SAFE":
            setArea(areas[i].current, areas[i].num, areas[i].name, areas[i].status, areas[i].info, areas[i].marker, areas[i].path, '#A2FF99', '#EFFFED', '#39DE2A');
            break;
        }}
  }


  var bldList = []
  function setArea(current, num, name, status, info, marker, path, outColor, overColor, lineColor){
      var bld = new google.maps.Polygon({
          path : path,
          strokeWeight: 3,
          strokeColor: lineColor,
          strokeOpacity: 0.7,
          strokeStyle: 'solid',
          fillColor: outColor,
          fillOpacity: 0.5
      });

        bldList.push(bld);
        bld.setMap(map);

        // eventfor mouseover
        google.maps.event.addListener(bld, 'mouseover', function() { 

          bld.setOptions({fillColor: overColor, fillOpacity: 0.7});
          infowindow.setContent(content); 
          infowindow.setMap(map);        
        });   

        // event for mouseout
        google.maps.event.addListener(bld, 'mouseout', function() { 

          bld.setOptions({fillColor: outColor, fillOpacity: 0.5});
          infowindow.close();

        });   

        // event for mouseclick
        google.maps.event.addListener(bld, 'click', function() { 
            infowindow.setContent(content); 
            infowindow.setMap(map);   
        });


        // change content by status
        if(status == "SAFE"){
          var content = '<div id="information">' +
                        '<h3>' + name + ' (' + num + ') </h4> ' + 
                        '<p id="status_safe">' + status + '</p>' +
                        '<p> 현재인원: ' + current + '</p>' +
                        '<h4> 최근 확진자 방문: </h4> <p>' + info + '</p>' +
                        '</div>'
        }
        else if(status == "EXCEEDED"){
          var content = '<div id="information">' +
                        '<h3>' + name + ' (' + num + ') </h4> ' + 
                        '<p id="status_exceeded">' + status + '</p>' +
                        '<p> 현재인원: ' + current + '</p>' +
                        '<h4> 최근 확진자 방문: </h4> <p>' + info + '</p>' +
                        '</div>'
        }
        else if(status == "VISITED"){
          var content = '<div id="information">' +
                        '<h3>' + name + ' (' + num + ') </h4> ' + 
                        '<p id="status_visited">' + status + '</p>' +
                        '<p> 현재인원: ' + current + '</p>' +
                        '<h4> 최근 확진자 방문: </h4> <p>' + info + '</p>' +
                        '</div>'
        }
  
        // create infoWindow
        var infowindow = new google.maps.InfoWindow({
            map,
            position : marker,
            content : content
        });
        infowindow.close();
  }


  // get GPS location 
  navigator.geolocation.watchPosition(success, error, options);

  var options = {
    enableHighAccuracy: true,
    timeout: 5000,
    maximumAge: 0
  };


  function error(err) {
    console.warn(ERROR('${err.code}): ${err.message}'));
  }


  function success(pos) {

    const geocoder = new google.maps.Geocoder();
    var crd = pos.coords;
    const latlngStr = [crd.latitude, crd.longitude];
    const latlng = {
      lat: parseFloat(latlngStr[0]),
      lng: parseFloat(latlngStr[1]),
    };
    geocoder
      .geocode({ location: latlng })
      .then((response) => {
        if (response.results[0]) {
          var placeID = response.results[0].place_id;
          addToFirebase(placeID)

          initAuthentication(initFirebase.bind(undefined, map))
        } else {
          window.alert("No results found");
        }
        
      })
      .catch((e) => window.alert("Geocoder failed due to: " + e));
  }


  // loop colorChange() by 3000ms
  setInterval(colorChange,3000)

}
