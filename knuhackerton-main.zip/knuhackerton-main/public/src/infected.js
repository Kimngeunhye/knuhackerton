// Add visitedInfo
for(var k = 0; k < infectedPerson.length; k++){
  
  if(infectedPerson[k].visitBuilding.length) {
    
      for(var l = 0; l < infectedPerson[k].visitBuilding.length; l++) {
  
        
        var building_index = buildings.indexOf(infectedPerson[k].visitBuilding[l]);
        var building_num = areas[building_index].num;
        
        areas[building_index].status = "VISITED";

        var visitedInfo="<ul>" +
                        "<li>대상: " + infectedPerson[k].college + "</li>" +
                        "<li>확진일자: " + infectedPerson[k].date.month + "/" + infectedPerson[k].date.day + "</li>" +
                        "<li>학교출입: <br>" + infectedPerson[k].info + "</li>" +
                        "</ul>"

        updateInfo(building_index, visitedInfo);

      }
  }
}

function updateInfo(index, visitedInfo) {
  if (areas[building_index].info[0] == "없음") {
    areas[building_index].info[0] = visitedInfo;
  }
  else {
    areas[building_index].info.push(visitedInfo);
  }
}


// Delete infectedPerson array after 14 days from first comfirmed date
var now = new Date();

var year = now.getFullYear();
var month = now.getMonth()+1;
var day = now.getDate();
var todayDate = new Date(year, month, day);


for (var i = 0; i< infectedPerson.length; i++) {
  if(infectedPerson[i].visitBuilding.length) {
      var confirmedDate = new Date(2021, infectedPerson[i].date.month, infectedPerson[i].date.day);
      var btwDay = (todayDate - confirmedDate) / (10006060*24);

      if(btwDay >= 14) {

        for(var m = 0; m < infectedPerson[i].visitBuilding.length; m++) {

          var building_index = buildings.indexOf(infectedPerson[i].visitBuilding[m]);

          if(areas[building_index].info.length == 1) {
            areas[building_index].status = "SAFE";
            areas[building_index].info = ["없음"];
          }
          else {
            areas[building_index].info.shift();
          }
        }
      }
  }
}